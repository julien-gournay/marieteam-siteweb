<meta charset="UTF-8"/> <!-- Formatage caractères -->

<link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" /> <!-- CSS Modules Flowbite -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Import Chart.js -->


<link rel="stylesheet" type="text/css" href="css/setting.css"> <!-- CSS : Couleurs par defaut -->
<link rel="stylesheet" type="text/css" href="css/defaut.css"> <!-- CSS : Composant et elements par defaut --> 

<link rel="shortcut icon" type="image/png" href="img/logosvg_mobile.svg"> <!-- Icon page navigateur -->
<meta name="viewport" content="width=device-width, initial-scale=1.0"/> <!-- Ajustement de la fenetre -->

<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>